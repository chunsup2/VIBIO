import os
import pandas as pd
import matplotlib.pyplot as plt

# ===================== 1) Manual Data Entry =====================
# Add your data points here as dictionaries.
# 'z': Latent dimension size
# 'kl': Beta (KL weight)
# 'auc': The AUC score
manual_data = [
    # --- z = 128 ---
    {"z": 128, "kl": 100.0, "auc": 0.5217},
    {"z": 128, "kl": 1.0, "auc": 0.5053},
    {"z": 128, "kl": 0.1, "auc": 0.5048},
    {"z": 128, "kl": 0.01, "auc": 0.5106},
    {"z": 128, "kl": 0.001, "auc": 0.5069},
    {"z": 128, "kl": 0.0001, "auc": 0.504},
    {"z": 128, "kl": 1e-05, "auc": 0.8852},
    {"z": 128, "kl": 1e-08, "auc": 0.5050},

    # --- z = 256 ---
    {"z": 256, "kl": 100.0, "auc": 0.5057},
    {"z": 256, "kl": 1.0, "auc": 0.8872},
    {"z": 256, "kl": 0.1, "auc": 0.9293},
    # {"z": 256, "kl": 0.01, "auc": 0.9130},  # Finding
    {"z": 256, "kl": 0.001, "auc": 0.9458},
    {"z": 256, "kl": 0.0001, "auc": 0.9326},  # Finding
    {"z": 256, "kl": 1e-05, "auc": 0.9511},
    {"z": 256, "kl": 1e-08, "auc": 0.8474},

    # --- z = 512 ---
    {"z": 512, "kl": 100.0, "auc": 0.8347},  # ACC: 0.5000
    {"z": 512, "kl": 1.0, "auc": 0.9443}, # ACC: 0.6936, 0.9182
    {"z": 512, "kl": 0.1, "auc": 0.9452},  # 0.9039
    {"z": 512, "kl": 0.01, "auc": 0.9474}, # 0.9132
    {"z": 512, "kl": 0.001, "auc": 0.9223},  # Finding
    {"z": 512, "kl": 0.0001, "auc": 0.9442},
    {"z": 512, "kl": 1e-05, "auc": 0.9491}, # ACC: 0.5735  # 0.9455
    {"z": 512, "kl": 1e-08, "auc": 0.8654},

    # # --- z = 1024 (Add your new points here) ---
    {"z": 1024, "kl": 100.0, "auc": 0.8195},
    {"z": 1024, "kl": 1.0, "auc": 0.8898}, # ACC:0.6418
    {"z": 1024, "kl": 0.1, "auc": 0.9147}, # ACC:0.509, Loss: 0.8966
    {"z": 1024, "kl": 0.01, "auc": 0.9496}, # ACC:0.6833, 0.8698, 0.8687
    # {"z": 1024, "kl": 0.001, "auc": 0.9044},  # Finding
    {"z": 1024, "kl": 0.0001, "auc": 0.9492},
    {"z": 1024, "kl": 1e-05, "auc": 0.9445},
    {"z": 1024, "kl": 1e-08, "auc": 0.8724},
]

manual_data_loss = [
    # --- z = 256 ---
    {"z": 256, "kl": 100.0, "auc": 0.5046},
    {"z": 256, "kl": 1.0, "auc": 0.8679},
    {"z": 256, "kl": 0.1, "auc": 0.8819},
    {"z": 256, "kl": 0.01, "auc": 0.8965},  # Finding
    {"z": 256, "kl": 0.001, "auc": 0.8377},
    {"z": 256, "kl": 0.0001, "auc": 0.9173},  # Finding
    {"z": 256, "kl": 1e-05, "auc": 0.8924},
    {"z": 256, "kl": 1e-08, "auc": 0.5049},

    # --- z = 512 ---
    {"z": 512, "kl": 100.0, "auc": 0.7528},  # ACC: 0.5085
    {"z": 512, "kl": 1.0, "auc": 0.9182},
    {"z": 512, "kl": 0.1, "auc": 0.9266},  # 0.8685
    {"z": 512, "kl": 0.01, "auc": 0.8976},
    {"z": 512, "kl": 0.001, "auc": 0.9052},  # Finding
    {"z": 512, "kl": 0.0001, "auc": 0.9316},
    {"z": 512, "kl": 1e-05, "auc": 0.9455},
    {"z": 512, "kl": 1e-08, "auc": 0.8246},

    # # --- z = 1024 (Add your new points here) ---
    {"z": 1024, "kl": 100.0, "auc": 0.7564},
    {"z": 1024, "kl": 1.0, "auc": 0.8759},  # ACC: 0.5
    {"z": 1024, "kl": 0.1, "auc": 0.8966},
    {"z": 1024, "kl": 0.01, "auc": 0.8698}, # 0.8697
    {"z": 1024, "kl": 0.001, "auc": 0.8931},  # Finding
    {"z": 1024, "kl": 0.0001, "auc": 0.9466},
    {"z": 1024, "kl": 1e-05, "auc": 0.9347},
    {"z": 1024, "kl": 1e-08, "auc": 0.8465},
]


# ===================== 2) Process Data =====================
df = pd.DataFrame(manual_data)

if df.empty:
    raise ValueError("No data found. Please add points to 'manual_data'.")

# Sort values to ensure the lines connect correctly
df = df.sort_values(["z", "kl"]).reset_index(drop=True)

# Optional: Print to check
print("Data to be plotted:")
print(df)

# ===================== 3) Plotting =====================
plt.figure(figsize=(8, 6))

# Loop through each unique 'z' dimension to create a separate line
for z_val in sorted(df["z"].unique()):
    # Filter data for this specific z dimension
    g = df[df["z"] == z_val]

    # Plot x=kl, y=auc
    plt.plot(g["kl"], g["auc"], marker="o", label=f"z={z_val}")

plt.xlabel("KL Weight (β)", fontsize=15)
plt.ylabel("AUC", fontsize=15)
plt.title("AUC vs β", fontsize=18)
plt.grid(True, which="both", linestyle="--", linewidth=0.5)

# Use log scale for X-axis since KL values vary by orders of magnitude
plt.xscale("log")

plt.legend(title="Latent Dim (z)")
plt.tight_layout()

# ===================== 4) Save Figure =====================
save_path = '/home/chunsup2/PycharmProjects/VIBIO/checkpoints/sks_choose/1.0/VIBIO-ABL/auc_vs_kl_summary_plot.png'

os.makedirs(os.path.dirname(save_path), exist_ok=True)
plt.savefig(save_path, dpi=300, bbox_inches="tight")
print(f"\nFigure saved to: {save_path}")

plt.show()