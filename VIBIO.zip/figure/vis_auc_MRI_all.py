import matplotlib.pyplot as plt
import os

# ========================
# 1. Data
# ========================
data_proportion = [0.005, 0.5, 1.0]

# AUC（示例占位，等你替换）
auc_cnn_io = [0.83142, 0.91277, 0.91543]
auc_vib_ce = [0.87018, 0.91432, 0.91701]
auc_vib_io = [0.87255, 0.91440, 0.91705]

# Std（如果没有可以先全设为 0，或者直接删掉 errorbar）
std_cnn_io = [0.00388, 0.00271, 0.00262]
std_vib_ce = [0.00340, 0.00265, 0.00259]
std_vib_io = [0.00330, 0.00265, 0.00261]

# ========================
# 2. Save path
# ========================
save_dir = "/home/chunsup2/PycharmProjects/IOVIB/"
os.makedirs(save_dir, exist_ok=True)
save_path = os.path.join(save_dir, "mri_data_proportion_auc.png")

# ========================
# 3. Plot
# ========================
plt.figure(figsize=(6, 4))

plt.errorbar(
    data_proportion, auc_cnn_io, yerr=std_cnn_io,
    fmt='-o', capsize=5, linewidth=0.8, markersize=2,
    label="CNN-IO"
)

plt.errorbar(
    data_proportion, auc_vib_ce, yerr=std_vib_ce,
    fmt='-s', capsize=5, linewidth=0.8, markersize=2,
    label="VIB-CE"
)

plt.errorbar(
    data_proportion, auc_vib_io, yerr=std_vib_io,
    fmt='-^', capsize=5, linewidth=0.8, markersize=2,
    label="VIB-IO"
)

# ========================
# 4. Labels & style
# ========================
plt.xlabel("Data Proportion", fontsize=12)
plt.ylabel("AUC", fontsize=12)
plt.xticks(data_proportion)

plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(fontsize=10)
plt.margins(y=0.15)
plt.tight_layout()

# ========================
# 5. Save & show
# ========================
plt.savefig(save_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"✅ 图像已保存到：{save_path}")
